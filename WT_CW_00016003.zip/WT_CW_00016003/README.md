# 00016003

This web application was created to fulfill Web Technology module’s requirements and does not represent an actual company or service. With the app you
may create, edit, delete and update the students information. App includes 5 pages that are home, edit, create, read and students pages. In home page
there is a description of the app you may go other pages in this page. In the create page I put the labels and inputs to enter detail of the employee.

# Employee recruitment
In today's world and age, everything is done online, so people give preference to their mobile, laptops and PCs cause it is portable,fast and easy. So happens with jobs, more and more corparations are creating their own websites to manage employee resources. Through those websites employees leave details that website ask and it is easy to manage the data for experts later on. I have created the same working web page for employee recruitmen.

git hib link : (https://github.com/hustle077/Employee-recruitment.git)
